<?php
/**
 * Created by PhpStorm.
 * User: Ramin angooti
 * Date: 5/8/16
 * Time: 2:33 PM
 */
defined('_JEXEC') or die('Restricted access');

require_once (JPATH_ADMINISTRATOR.'/components/com_j2store/library/plugins/payment.php');
require_once (JPATH_ADMINISTRATOR.'/components/com_j2store/helpers/j2store.php');



class plgJ2StorePayment_jahanpay extends J2StorePaymentPlugin
{
    /**
     * @var $_element  string  Should always correspond with the plugin's filename,
     *                         forcing it to be unique
     */
    var $_element   = 'payment_jahanpay';
    private $merchantCode = '';
    private $callBackUrl = '';
    private $redirectTojahanpay = '';

    public function __construct(& $subject, $config)
    {
        parent::__construct($subject, $config);
        $this->loadLanguage( '', JPATH_ADMINISTRATOR );
        $this->merchantCode = trim($this->params->get('merchant_id'));
        $this->callBackUrl = JUri::root().'/index.php?option=com_j2store&view=checkout&task=confirmPayment&orderpayment_type=payment_jahanpay&paction=callback';
        $this->redirectTojahanpay = 'https://www.jahanpay.me/pg/StartPay/';
    }

    public function _renderForm( $data )
    {
        $vars = new JObject();
        $vars->message = JText::_("J2STORE_jahanpay_PAYMENT_MESSAGE");
        $html = $this->_getLayout('form', $vars);
        return $html;
    }

    public function _prePayment($data)
    {
        $vars = new StdClass();
        $vars->display_name = $this->params->get('display_name', '');
        $vars->onbeforepayment_text = JText::_("J2STORE_jahanpay_PAYMENT_PREPARATION_MESSAGE");

		
		$amount = round($data['orderpayment_amount']);
		$return = $this->callBackUrl;

		 $client = new SoapClient("http://www.jpws.me/directservice?wsdl");
		$api = trim($this->params->get('merchant_id'));
		$amount = $amount/10; //Tooman
		$callbackUrl = $return;
		$orderId = $data['order_id'];
         $res = $client->requestpayment($api, $amount, $callbackUrl, $orderId);	

        if($res['result']){
        session_start();
        $_SESSION['jp_au']=$res['au'];
        $_SESSION['amount']=$amount;
        $_SESSION['orderid']=$orderId;
        
            echo ('<div style="display:none;">'.$res['form'].'</div><script>document.forms["jahanpay"].submit();</script>');
        }else{
			echo '<br>خطا: <br>'.$res['result'];
		}		

        // $vars->error = $this->statusText($request->Status);
        // $html = $this->_getLayout('prepayment', $vars);
        return $html;
    }

    public function _postPayment($data)
    {
        $vars = new JObject();
        //get order id
        session_start();
        
        $orderId = $_SESSION['orderid'];
        $au = $_SESSION['jp_au'];
        // get instatnce of j2store table
        F0FTable::addIncludePath(JPATH_ADMINISTRATOR.'/components/com_j2store/tables');
        $order = F0FTable::getInstance('Order', 'J2StoreTable')->getClone();
        $order->load(array('order_id' => $orderId));

        if($order->load(array('order_id' => $orderId))){

            $currency = J2Store::currency();
            $currencyValues= $this->getCurrency($order);
            $orderPaymentAmount = $currency->format($order->order_total, $currencyValues['currency_code'], $currencyValues['currency_value'], false);
            $orderPaymentAmount = (int)($orderPaymentAmount / 10);

            $order->add_history(JText::_('J2STORE_CALLBACK_RESPONSE_RECEIVED'));

	
		$api = $this->params->get('merchant_id');
		$amount = $orderPaymentAmount; //Tooman
		
		$client = new SoapClient("http://www.jpws.me/directservice?wsdl");
        $result = $client->verification($api , $amount , $au , $orderId, $_POST + $_GET );
 
		if( ! empty($result['result']) and $result['result'] == 1){
			$order->payment_complete();
			$order->empty_cart();
			$message = JText::_("J2STORE_jahanpay_PAYMENT_SUCCESS") . "\n";
			$message .= JText::_("J2STORE_jahanpay_PAYMENT_ZP_REF") . $au;
			$vars->message = $message;
			$html = $this->_getLayout('postpayment', $vars);
			return $html;				
		}
		else{
			$vars->message = $result['result'];
			$html = $this->_getLayout('postpayment', $vars);
			return $html;			
		}			

            return $html;

        }

        $vars->message = JText::_("J2STORE_jahanpay_PAYMENT_PAGE_ERROR");
        $html = $this->_getLayout('postpayment', $vars);
        return $html;
    }

    private function statusText($status)
    {
        return JText::_("J2STORE_jahanpay_PAYMENT_STATUS_" . $status );
    }
}